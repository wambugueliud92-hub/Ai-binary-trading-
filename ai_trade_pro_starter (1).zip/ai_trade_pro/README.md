# AI Trade Pro

A starter project for a **signals-only** binary-options market analysis dashboard.

## What is included
- React + Vite responsive dashboard (web and Android-ready via Capacitor)
- FastAPI backend with health, market list, signal, and signal-history endpoints
- Transparent indicator engine: EMA trend, RSI, MACD histogram, and candle momentum
- Demo OHLCV feed so the project runs without broker credentials
- Platform selector for Quotex, Pocket Option, Deriv, Binomo, Olymp Trade, and generic markets
- Clear demo-data labeling and risk disclosures

## Important limitations
This starter does **not** connect to broker accounts, place trades, or provide guaranteed predictions. The included feed is synthetic demo data, not live prices. Before using real markets, connect a licensed/authorized market-data provider and verify its terms, symbol mapping, timestamps, and latency. Binary options are high-risk and may be restricted or prohibited in some jurisdictions. Check local law and platform rules before use.

## Run locally

### Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs

### Web dashboard
In a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite (normally http://localhost:5173).

The Vite dev server proxies `/api` to `http://localhost:8000`.

## Android build (Capacitor)
Install Android Studio and the Android SDK, then:
```bash
cd frontend
npm install
npm run build
npm run android:add
npm run android:sync
npm run android:open
```
Build an APK from Android Studio. Capacitor requires a configured Android toolchain.

## Production deployment outline
- Deploy `backend/` to a Python host such as Render or Railway. Set its start command to:
  `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
- Deploy `frontend/` to Vercel or Netlify. Set `VITE_API_BASE` to the deployed backend URL, and configure SPA fallback to `index.html`.
- For Android, set `VITE_API_BASE` to the HTTPS backend URL before building the APK.

## Replace the demo feed
Implement `MarketDataProvider` in `backend/app/market_data.py` using a provider whose API terms allow your intended use. The current `DemoMarketDataProvider` intentionally generates synthetic candles and labels them as demo.

## Signal interpretation
The engine returns `CALL`, `PUT`, or `WAIT`, plus a heuristic confidence score. This is an indicator-agreement score, **not** a calibrated probability of success. Signals are educational analysis only and can be wrong, especially on short expiries.
