import React, { useEffect, useState } from 'react'
import { Activity, ArrowDownRight, ArrowUpRight, Bell, BrainCircuit, Clock3, RefreshCw, ShieldAlert, Signal, TrendingUp } from 'lucide-react'

const API = import.meta.env.VITE_API_BASE || ''
const platforms = ['Quotex', 'Pocket Option', 'Deriv', 'Binomo', 'Olymp Trade', 'Generic']
const timeframes = ['1m', '5m', '15m']

export default function App() {
  const [platform, setPlatform] = useState('Deriv')
  const [symbol, setSymbol] = useState('EUR/USD')
  const [timeframe, setTimeframe] = useState('1m')
  const [signal, setSignal] = useState(null)
  const [history, setHistory] = useState([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  async function refresh() {
    setBusy(true); setError('')
    try {
      const q = new URLSearchParams({ platform, symbol, timeframe })
      const [s, h] = await Promise.all([
        fetch(`${API}/api/signal?${q}`).then(r => { if (!r.ok) throw new Error('Signal API unavailable'); return r.json() }),
        fetch(`${API}/api/history`).then(r => r.json())
      ])
      setSignal(s); setHistory(h.items || [])
    } catch (e) { setError(`${e.message}. Start the FastAPI backend on port 8000.`) }
    finally { setBusy(false) }
  }
  useEffect(() => { refresh() }, [])
  const direction = signal?.direction || 'WAIT'
  const bullish = direction === 'CALL'
  const bearish = direction === 'PUT'
  return <div className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brandIcon"><BrainCircuit size={22}/></div><div><b>AI TRADE PRO</b><small>MARKET INTELLIGENCE</small></div></div>
      <div className="nav active"><Activity size={18}/> Dashboard</div>
      <div className="nav"><Signal size={18}/> AI Signals</div>
      <div className="nav"><Clock3 size={18}/> Signal history</div>
      <div className="sideNote"><ShieldAlert size={17}/><span>Signals are informational. Always verify market data and manage risk.</span></div>
      <div className="profile"><div className="avatar">A</div><div><b>Demo workspace</b><small>Signals-only account</small></div></div>
    </aside>
    <main className="main">
      <header><div><div className="eyebrow">MARKET OVERVIEW / DASHBOARD</div><h1>Trading dashboard</h1><p>AI-assisted technical analysis across multiple platforms.</p></div><div className="headerRight"><span className="demoPill"><i/> DEMO DATA</span><button className="iconBtn" aria-label="Notifications"><Bell size={18}/></button></div></header>
      <section className="notice"><ShieldAlert size={19}/><div><b>Demo environment</b><span>Prices and signals currently use synthetic sample candles. This is not a live trading feed or a recommendation to trade.</span></div></section>
      <section className="stats">
        <div className="stat"><span>Selected platform</span><b>{platform}</b><small><Activity size={13}/> Multi-platform interface</small></div>
        <div className="stat"><span>Market</span><b>{symbol}</b><small><TrendingUp size={13}/> Demo market</small></div>
        <div className="stat"><span>Timeframe</span><b>{timeframe}</b><small><Clock3 size={13}/> Analysis interval</small></div>
        <div className="stat"><span>Engine status</span><b className="online">● Ready</b><small><BrainCircuit size={13}/> EMA · RSI · MACD</small></div>
      </section>
      <section className="workspace">
        <div className="panel controls">
          <div className="panelHead"><div><span className="eyebrow">CONFIGURATION</span><h2>Signal settings</h2></div><span className="tag">MANUAL</span></div>
          <label>Trading platform</label><select value={platform} onChange={e=>setPlatform(e.target.value)}>{platforms.map(p=><option key={p}>{p}</option>)}</select>
          <label>Asset / market</label><select value={symbol} onChange={e=>setSymbol(e.target.value)}>{['EUR/USD','GBP/USD','USD/JPY','AUD/USD','BTC/USD','ETH/USD'].map(s=><option key={s}>{s}</option>)}</select>
          <label>Analysis timeframe</label><div className="timeOptions">{timeframes.map(t=><button key={t} onClick={()=>setTimeframe(t)} className={timeframe===t?'chosen':''}>{t}</button>)}</div>
          <button className="primary" onClick={refresh} disabled={busy}><RefreshCw size={16} className={busy?'spin':''}/>{busy?'Analyzing…':'Generate AI signal'}</button>
          {error && <p className="error">{error}</p>}
          <p className="micro">Platform selection changes the signal context only. No broker account is connected.</p>
        </div>
        <div className="panel signalPanel">
          <div className="panelHead"><div><span className="eyebrow">LATEST ANALYSIS</span><h2>AI signal</h2></div><span className="liveTag"><i/> ENGINE READY</span></div>
          <div className={`signalHero ${bullish?'call':bearish?'put':''}`}>
            <div className="signalIcon">{bullish?<ArrowUpRight/>:bearish?<ArrowDownRight/>:<Activity/>}</div>
            <div><span className="signalLabel">SUGGESTED DIRECTION</span><div className="direction">{direction}</div><small>{signal?`${signal.symbol} · ${signal.timeframe} · ${signal.platform}`:'Waiting for analysis'}</small></div>
            <div className="confidence"><b>{signal?.confidence ?? '—'}%</b><small>indicator agreement</small></div>
          </div>
          <div className="signalDetails"><div><span>Reference price</span><b>{signal?.entry_price ?? '—'}</b></div><div><span>Generated</span><b>{signal?new Date(signal.generated_at*1000).toLocaleTimeString(): '—'}</b></div><div><span>Data source</span><b>Demo feed</b></div></div>
          <div className="reasonTitle">Indicator breakdown</div>
          <ul className="reasons">{(signal?.reasons || ['Generate a signal to view indicator analysis.']).map((r,i)=><li key={i}><i/>{r}</li>)}</ul>
          <p className="micro">Confidence is a heuristic indicator-agreement score, not a statistically calibrated win probability.</p>
        </div>
      </section>
      <section className="panel historyPanel">
        <div className="panelHead"><div><span className="eyebrow">RECENT ACTIVITY</span><h2>Signal history</h2></div><span className="tag">{history.length} RECORDS</span></div>
        <div className="tableWrap"><table><thead><tr><th>Market</th><th>Platform</th><th>Timeframe</th><th>Direction</th><th>Score</th><th>Time</th></tr></thead><tbody>
          {history.slice(0,8).map(item=><tr key={item.id}><td>{item.symbol}</td><td>{item.platform}</td><td>{item.timeframe}</td><td><span className={`directionTag ${item.direction.toLowerCase()}`}>{item.direction}</span></td><td>{item.confidence}%</td><td>{new Date(item.generated_at*1000).toLocaleTimeString()}</td></tr>)}
          {!history.length && <tr><td colSpan="6" className="empty">No signals generated yet.</td></tr>}
        </tbody></table></div>
      </section>
      <footer>AI TRADE PRO <span>Educational technical analysis · No trade execution · Demo data</span></footer>
    </main>
  </div>
}
