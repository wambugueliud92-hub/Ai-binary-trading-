from pydantic import BaseModel
from typing import Literal

class Candle(BaseModel):
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float

class Signal(BaseModel):
    id: str
    platform: str
    symbol: str
    timeframe: str
    direction: Literal["CALL", "PUT", "WAIT"]
    confidence: int
    entry_price: float
    generated_at: int
    reasons: list[str]
    data_mode: Literal["DEMO", "LIVE"] = "DEMO"
    disclaimer: str = "Heuristic indicator score, not a probability or guarantee."
