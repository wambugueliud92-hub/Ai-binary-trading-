import time, uuid
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from app.market_data import DemoMarketDataProvider
from app.indicators import analyze

app = FastAPI(title="AI Trade Pro API", version="0.1.0",
              description="Signals-only educational demo. Prices are synthetic.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False,
                   allow_methods=["*"], allow_headers=["*"])
provider = DemoMarketDataProvider()
history = []
PLATFORMS = ["Quotex", "Pocket Option", "Deriv", "Binomo", "Olymp Trade", "Generic"]
SYMBOLS = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "BTC/USD", "ETH/USD"]

@app.get("/api/health")
async def health():
    return {"status": "ok", "data_mode": "DEMO", "message": "Synthetic demo feed; not live market data."}

@app.get("/api/markets")
async def markets():
    return {"platforms": PLATFORMS, "symbols": SYMBOLS, "timeframes": ["1m", "5m", "15m"]}

@app.get("/api/candles")
async def candles(symbol: str = "EUR/USD", timeframe: str = "1m", limit: int = 120):
    if timeframe not in ["1m", "5m", "15m"]:
        raise HTTPException(400, "Unsupported timeframe")
    rows = await provider.candles(symbol, timeframe, max(35, min(limit, 300)))
    return {"symbol": symbol, "timeframe": timeframe, "data_mode": "DEMO",
            "candles": [c.model_dump() for c in rows]}

@app.get("/api/signal")
async def signal(platform: str = "Generic", symbol: str = "EUR/USD", timeframe: str = "1m"):
    if platform not in PLATFORMS:
        raise HTTPException(400, "Unsupported platform")
    if timeframe not in ["1m", "5m", "15m"]:
        raise HTTPException(400, "Unsupported timeframe")
    candles = await provider.candles(symbol, timeframe, 120)
    direction, confidence, reasons = analyze([c.close for c in candles])
    result = {
        "id": str(uuid.uuid4()), "platform": platform, "symbol": symbol,
        "timeframe": timeframe, "direction": direction, "confidence": confidence,
        "entry_price": candles[-1].close, "generated_at": int(time.time()),
        "reasons": reasons, "data_mode": "DEMO",
        "disclaimer": "Synthetic demo data. Heuristic score is not a probability or guarantee."
    }
    history.insert(0, result)
    del history[100:]
    return result

@app.get("/api/history")
async def get_history():
    return {"items": history}
