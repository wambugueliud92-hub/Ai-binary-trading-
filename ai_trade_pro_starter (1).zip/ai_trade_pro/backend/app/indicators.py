def ema(values: list[float], period: int) -> list[float]:
    if not values:
        return []
    alpha = 2 / (period + 1)
    result = [values[0]]
    for value in values[1:]:
        result.append(alpha * value + (1 - alpha) * result[-1])
    return result

def rsi(values: list[float], period: int = 14) -> float:
    if len(values) <= period:
        return 50.0
    gains, losses = [], []
    for a, b in zip(values[-period-1:-1], values[-period:]):
        delta = b - a
        gains.append(max(delta, 0))
        losses.append(max(-delta, 0))
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100.0 if avg_gain else 50.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def analyze(closes: list[float]) -> tuple[str, int, list[str]]:
    if len(closes) < 35:
        return "WAIT", 0, ["Not enough candles for analysis."]
    fast, slow = ema(closes, 9), ema(closes, 21)
    r = rsi(closes)
    macd_line = [a - b for a, b in zip(ema(closes, 12), ema(closes, 26))]
    macd_signal = ema(macd_line, 9)
    hist = macd_line[-1] - macd_signal[-1]
    momentum = closes[-1] - closes[-4]
    votes = []
    reasons = []
    if fast[-1] > slow[-1]:
        votes.append(1); reasons.append("EMA 9 is above EMA 21 (uptrend bias).")
    else:
        votes.append(-1); reasons.append("EMA 9 is below EMA 21 (downtrend bias).")
    if r >= 55:
        votes.append(1); reasons.append(f"RSI is {r:.1f}, showing positive momentum.")
    elif r <= 45:
        votes.append(-1); reasons.append(f"RSI is {r:.1f}, showing negative momentum.")
    else:
        votes.append(0); reasons.append(f"RSI is {r:.1f}, in a neutral zone.")
    if hist > 0:
        votes.append(1); reasons.append("MACD histogram is positive.")
    elif hist < 0:
        votes.append(-1); reasons.append("MACD histogram is negative.")
    else:
        votes.append(0); reasons.append("MACD histogram is flat.")
    if momentum > 0:
        votes.append(1)
    elif momentum < 0:
        votes.append(-1)
    score = sum(votes)
    agreement = max(votes.count(1), votes.count(-1)) / len(votes)
    confidence = round(agreement * 100)
    if score >= 2:
        return "CALL", confidence, reasons
    if score <= -2:
        return "PUT", confidence, reasons
    return "WAIT", confidence, reasons + ["Indicators are mixed; wait for clearer alignment."]
