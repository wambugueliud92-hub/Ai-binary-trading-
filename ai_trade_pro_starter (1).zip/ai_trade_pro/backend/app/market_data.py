import math, time
from app.schemas import Candle

class DemoMarketDataProvider:
    \"\"\"Synthetic data for UI development only. Never represents live market prices.\"\"\"
    async def candles(self, symbol: str, timeframe: str, limit: int = 120) -> list[Candle]:
        step = {"1m": 60, "5m": 300, "15m": 900}.get(timeframe, 60)
        now = int(time.time())
        seed = sum(ord(c) for c in symbol) % 37
        base = 1.08 + seed * 0.003
        out = []
        previous = base
        for i in range(limit):
            phase = i / 5.5 + seed
            drift = math.sin(phase) * 0.0008 + math.sin(i / 17) * 0.00035
            close = previous + drift
            open_ = previous
            spread = abs(math.sin(i * 1.73 + seed)) * 0.00035 + 0.00005
            high = max(open_, close) + spread
            low = min(open_, close) - spread
            out.append(Candle(
                timestamp=now - (limit - i) * step,
                open=round(open_, 6), high=round(high, 6),
                low=round(low, 6), close=round(close, 6),
                volume=100 + abs(math.sin(i)) * 900
            ))
            previous = close
        return out
